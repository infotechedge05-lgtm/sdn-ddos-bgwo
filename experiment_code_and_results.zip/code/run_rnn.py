"""usage: run_rnn.py task mode featset seed out.json   (featset: all | sel)"""
import sys, json, time, numpy as np
sys.path.insert(0, '/home/claude/exp')
from rnn import RNNClassifier
from metrics import binary, multi
task, mode, feat, seed, out = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]
CW = sys.argv[6] if len(sys.argv) > 6 else 'sqrt'
LR = float(sys.argv[7]) if len(sys.argv) > 7 else 3e-3
EVAL_TEST = (sys.argv[8] if len(sys.argv) > 8 else '1') == '1'
PE = (sys.argv[9] if len(sys.argv) > 9 else '1') == '1'
HU = int(sys.argv[10]) if len(sys.argv) > 10 else 64
d = np.load('/home/claude/exp/data.npz')
X, y, tr, va, te = d['X'], d['y'], d['tr'], d['va'], d['te']
if feat == 'sel':
    mask = np.array(json.load(open('/home/claude/exp/selected.json'))['mask'], bool)
    X = X[:, mask]
yy = (y > 0).astype(int) if task == 'binary' else y
K = int(yy.max()) + 1
cnt = np.bincount(yy[tr], minlength=K)
cw = (len(tr) / (K * cnt)).astype(np.float64)
cw = {'bal': cw, 'sqrt': np.sqrt(cw), 'none': np.ones(K)}[CW]
m = RNNClassifier(T=X.shape[1], K=K, H=HU, A=HU, mode=mode, dropout=0.3, lr=LR, seed=seed, posenc=PE)
t0 = time.time()
hist = m.fit(X[tr], yy[tr], X[va], yy[va], cw, epochs=30, bs=512, patience=5, lr_decay=0.5,
             log=lambda s: print(s, flush=True))
ttrain = time.time() - t0
Pv = m.predict_proba(X[va]).argmax(1)
val = binary(yy[va], Pv) if task == 'binary' else multi(yy[va], Pv, K)
if not EVAL_TEST:
    json.dump(dict(val=val, cw=CW, lr=LR, posenc=PE, H=HU, epochs=len(hist), hist=hist), open(out, 'w'), indent=1)
    print('VAL', {k: round(v, 3) for k, v in val.items() if isinstance(v, float)}); sys.exit()
t0 = time.time(); P = m.predict_proba(X[te]); tinf = time.time() - t0
yp = P.argmax(1)
r = binary(yy[te], yp) if task == 'binary' else multi(yy[te], yp, K)
r.update(val=val, cw=CW, lr=LR, posenc=PE, H=HU, train_s=ttrain, infer_us=1e6 * tinf / len(te), epochs=len(hist), hist=hist,
         n_features=int(X.shape[1]), task=task, mode=mode, feat=feat, seed=seed)
if mode == 'att':   # mean attention weight per input feature on test set
    A = []
    for i in range(0, len(te), 4096):
        m.forward(X[te[i:i + 4096]]); A.append(m._cache['a'])
    r['mean_attention'] = np.concatenate(A).mean(0).tolist()
json.dump(r, open(out, 'w'), indent=1)
print({k: v for k, v in r.items() if isinstance(v, float)})
