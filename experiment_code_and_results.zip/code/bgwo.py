"""Binary Grey Wolf Optimizer (sigmoid transfer) with KNN wrapper fitness."""
import sys, json, time, numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import balanced_accuracy_score

data = np.load(sys.argv[1]); out = sys.argv[2]
seeds = [int(s) for s in sys.argv[3].split(',')]
X, y, tr, va = data['X'], data['y'], data['tr'], data['va']
POP, TMAX, LAM, K = 20, 50, 0.99, 5
N_FIT_TR, N_FIT_VA = 10000, 5000

def strat_sample(ix, n, rng):
    out = []
    for c in np.unique(y[ix]):
        cix = ix[y[ix] == c]
        k = max(1, int(round(n * len(cix) / len(ix))))
        out.append(rng.choice(cix, min(k, len(cix)), replace=False))
    return np.concatenate(out)

r0 = np.random.default_rng(123)
ftr, fva = strat_sample(tr, N_FIT_TR, r0), strat_sample(va, N_FIT_VA, r0)
Xa, ya, Xb, yb = X[ftr], y[ftr], X[fva], y[fva]
D = X.shape[1]
cache = {}
def fitness(mask):
    key = mask.tobytes()
    if key in cache: return cache[key]
    if mask.sum() == 0: return 1.0, 1.0
    knn = KNeighborsClassifier(n_neighbors=K, n_jobs=1).fit(Xa[:, mask], ya)
    err = 1 - balanced_accuracy_score(yb, knn.predict(Xb[:, mask]))
    f = LAM * err + (1 - LAM) * mask.sum() / D
    cache[key] = (f, err)
    return f, err

def to_bin(Xc, rng):
    S = 1 / (1 + np.exp(-10 * (Xc - 0.5)))
    return S >= rng.random(Xc.shape)

results = []
full_f, full_err = fitness(np.ones(D, bool))
for seed in seeds:
    rng = np.random.default_rng(seed); t0 = time.time()
    Xc = rng.random((POP, D))
    B = to_bin(Xc, rng)
    F = np.array([fitness(b)[0] for b in B])
    order = np.argsort(F)
    leaders = [(Xc[i].copy(), B[i].copy(), F[i]) for i in order[:3]]
    curve = [float(leaders[0][2])]
    for t in range(TMAX):
        a = 2 - 2 * t / TMAX
        newX = np.zeros_like(Xc)
        for (Xp, _, _) in leaders:
            A = 2 * a * rng.random((POP, D)) - a
            C = 2 * rng.random((POP, D))
            Dd = np.abs(C * Xp - Xc)
            newX += Xp - A * Dd
        Xc = newX / 3
        B = to_bin(Xc, rng)
        F = np.array([fitness(b)[0] for b in B])
        pool = leaders + [(Xc[i].copy(), B[i].copy(), F[i]) for i in range(POP)]
        pool.sort(key=lambda z: z[2])
        uniq, seen = [], set()
        for z in pool:
            k = z[1].tobytes()
            if k in seen: continue
            seen.add(k); uniq.append(z)
            if len(uniq) == 3: break
        leaders = uniq
        curve.append(float(leaders[0][2]))
    best = leaders[0]
    f, err = fitness(best[1])
    results.append(dict(seed=seed, fitness=float(f), bal_err=float(err), n_sel=int(best[1].sum()),
                        mask=best[1].astype(int).tolist(), curve=curve, secs=time.time() - t0))
    print(seed, f, err, int(best[1].sum()), round(time.time() - t0, 1), flush=True)
json.dump(dict(full_fitness=float(full_f), full_bal_err=float(full_err), D=D, pop=POP, tmax=TMAX,
               lam=LAM, k=K, n_fit_train=len(ftr), n_fit_val=len(fva), runs=results),
          open(out, 'w'), indent=1)
