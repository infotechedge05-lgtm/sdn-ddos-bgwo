import json, glob, numpy as np
R = '/home/claude/exp/res/'
out = {}
ca, cs = json.load(open(R + 'classic_all.json')), json.load(open(R + 'classic_sel.json'))
def pick(r, keys): return {k: float(r[k]) for k in keys if k in r}
B = ['acc', 'prec', 'rec', 'f1', 'fpr', 'train_s', 'infer_us']
M = ['acc', 'prec', 'rec', 'f1', 'train_s', 'infer_us']
for task, keys in (('binary', B), ('multi', M)):
    rows = []
    for name in ('KNN', 'Random Forest', 'Linear SVM', 'MLP (DNN)'):
        rows.append(dict(model=name, feat=70, **pick(ca[f'{task}|{name}'], keys)))
        rows.append(dict(model=name, feat=14, **pick(cs[f'{task}|{name}'], keys)))
    for mode, lab in (('uni', 'LSTM'), ('bi', 'BiLSTM')):
        r = json.load(open(R + f'{task}_{mode}_sel_42.json'))
        rows.append(dict(model=lab, feat=14, epochs=r['epochs'], **pick(r, keys)))
    if task == 'binary':
        r = json.load(open(R + f'{task}_att_all_42.json'))
        rows.append(dict(model='Att-BiLSTM', feat=70, epochs=r['epochs'], **pick(r, keys)))
    runs = [json.load(open(f)) for f in sorted(glob.glob(R + f'{task}_att_sel_*.json'))]
    agg = dict(model='BGWO + Att-BiLSTM (proposed)', feat=14, n_seeds=len(runs),
               epochs=[r['epochs'] for r in runs])
    for k in keys:
        v = np.array([r[k] for r in runs], float)
        agg[k] = float(v.mean()); agg[k + '_sd'] = float(v.std(ddof=1)) if len(v) > 1 else 0.0
    if task == 'multi':
        pc = np.array([r['per_class_f1'] for r in runs]); agg['per_class_f1'] = pc.mean(0).tolist()
        agg['per_class_f1_sd'] = pc.std(0, ddof=1).tolist()
        agg['cm_seed42'] = json.load(open(R + 'multi_att_sel_42.json'))['cm']
        rf = cs['multi|Random Forest']; agg['rf14_per_class_f1'] = rf['per_class_f1']
        agg['rf70_per_class_f1'] = ca['multi|Random Forest']['per_class_f1']
    else:
        agg['fp'] = [r['fp'] for r in runs]; agg['fn'] = [r['fn'] for r in runs]
    att = np.array([r['mean_attention'] for r in runs]); agg['mean_attention'] = att.mean(0).tolist()
    rows.append(agg)
    out[task] = rows
b = json.load(open('/home/claude/exp/bgwo.json'))
out['bgwo'] = dict(full_fitness=b['full_fitness'], full_bal_err=b['full_bal_err'],
                   runs=[dict(seed=r['seed'], n_sel=r['n_sel'], bal_err=r['bal_err'], fitness=r['fitness'],
                              secs=r['secs']) for r in b['runs']])
out['selected'] = json.load(open('/home/claude/exp/selected.json'))['names']
out['info'] = {k: v for k, v in json.load(open('/home/claude/exp/data_info.json')).items() if k != 'features'}
json.dump(out, open('/home/claude/exp/final_results.json', 'w'), indent=1)
for t in ('binary', 'multi'):
    print(t)
    for r in out[t]:
        print(f"  {r['model'][:28]:28s} {r['feat']:3d} " + ' '.join(
            f"{k}={r[k]:.2f}" + (f"±{r[k+'_sd']:.2f}" if k + '_sd' in r else '') for k in (B if t == 'binary' else M) if k in r))
