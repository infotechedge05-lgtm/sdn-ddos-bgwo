import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             confusion_matrix)

def binary(yt, yp):
    tn, fp, fn, tp = confusion_matrix(yt, yp, labels=[0, 1]).ravel()
    return dict(acc=100 * accuracy_score(yt, yp), prec=100 * precision_score(yt, yp, zero_division=0),
                rec=100 * recall_score(yt, yp), f1=100 * f1_score(yt, yp), fpr=100 * fp / (fp + tn),
                tp=int(tp), tn=int(tn), fp=int(fp), fn=int(fn))

def multi(yt, yp, K=6):
    return dict(acc=100 * accuracy_score(yt, yp),
                prec=100 * precision_score(yt, yp, average='macro', zero_division=0),
                rec=100 * recall_score(yt, yp, average='macro'),
                f1=100 * f1_score(yt, yp, average='macro'),
                per_class_f1=(100 * f1_score(yt, yp, average=None, labels=list(range(K)))).tolist(),
                cm=confusion_matrix(yt, yp, labels=list(range(K))).tolist())
