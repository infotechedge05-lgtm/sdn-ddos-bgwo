import sys, json, time, numpy as np
sys.path.insert(0, '/home/claude/exp')
from metrics import binary, multi
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.neural_network import MLPClassifier

d = np.load('/home/claude/exp/data.npz'); out = sys.argv[1]
X, y, tr, va, te = d['X'], d['y'], d['tr'], d['va'], d['te']
if len(sys.argv) > 2 and sys.argv[2] == 'sel':
    X = X[:, np.array(json.load(open('/home/claude/exp/selected.json'))['mask'], bool)]
models = {
    'KNN': lambda: KNeighborsClassifier(n_neighbors=5, n_jobs=1),
    'Random Forest': lambda: RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                                    random_state=42, n_jobs=1),
    'Linear SVM': lambda: LinearSVC(C=1.0, class_weight='balanced', max_iter=5000, random_state=42),
    'MLP (DNN)': lambda: MLPClassifier(hidden_layer_sizes=(128, 64), early_stopping=True,
                                       random_state=42, max_iter=100),
}
res = {}
for task in ('binary', 'multi'):
    yy = (y > 0).astype(int) if task == 'binary' else y
    for name, mk in models.items():
        m = mk(); t0 = time.time(); m.fit(X[tr], yy[tr]); ttrain = time.time() - t0
        t0 = time.time(); yp = m.predict(X[te]); tinf = time.time() - t0
        r = binary(yy[te], yp) if task == 'binary' else multi(yy[te], yp)
        r.update(train_s=ttrain, infer_us=1e6 * tinf / len(te))
        res[f'{task}|{name}'] = r
        print(task, name, {k: round(v, 3) for k, v in r.items() if isinstance(v, float)}, flush=True)
json.dump(res, open(out, 'w'), indent=1)
