import sys, json, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
src, out = sys.argv[1], sys.argv[2]
df = pd.read_csv(src)
n0 = len(df)
df = df.drop(columns=['Source IP', 'Source Port', 'Destination IP', 'Timestamp'])
df = df.drop_duplicates().reset_index(drop=True)
classes = ['benign', 'ddos', 'goldeneye', 'hulk', 'slowhttptest', 'slowloris']
y = df['Label'].map({c: i for i, c in enumerate(classes)}).to_numpy()
X = df.drop(columns=['Label'])
X = pd.get_dummies(X, columns=['Protocol'], prefix='Protocol', dtype=float)
names = list(X.columns)
X = X.to_numpy(dtype=np.float64)
idx = np.arange(len(y))
tr, te = train_test_split(idx, test_size=0.20, stratify=y, random_state=42)
tr, va = train_test_split(tr, test_size=0.125, stratify=y[tr], random_state=42)  # 0.125*0.8 = 0.10
Xs = np.sign(X) * np.log1p(np.abs(X))          # compress heavy-tailed flow statistics
mn, mx = Xs[tr].min(0), Xs[tr].max(0)
rngv = np.where(mx - mn > 0, mx - mn, 1.0)
Xn = np.clip((Xs - mn) / rngv, 0, 1).astype(np.float32)
keep = (mx - mn) > 0                            # drop attributes constant in training split
Xn = Xn[:, keep]; names = [n for n, k in zip(names, keep) if k]
np.savez_compressed(out, X=Xn, y=y, tr=tr, va=va, te=te)
info = dict(rows_raw=n0, rows_dedup=len(y), dup_removed=n0 - len(y), n_features=len(names),
            dropped_constant=int((~keep).sum()), features=names, classes=classes,
            counts={c: int((y == i).sum()) for i, c in enumerate(classes)},
            split={'train': len(tr), 'val': len(va), 'test': len(te)},
            split_counts={s: {c: int((y[ix] == i).sum()) for i, c in enumerate(classes)}
                          for s, ix in (('train', tr), ('val', va), ('test', te))})
json.dump(info, open(out.replace('.npz', '_info.json'), 'w'), indent=1)
print(json.dumps({k: v for k, v in info.items() if k != 'features'}, indent=1))
