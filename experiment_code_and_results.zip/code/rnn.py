"""NumPy implementation of LSTM / BiLSTM / attention-BiLSTM classifiers with
full backpropagation through time and Adam. Each flow's selected features are
treated as a sequence of T scalar time steps."""
import numpy as np

def sigmoid(x):
    return 0.5 * (1.0 + np.tanh(0.5 * x))

class RNNClassifier:
    def __init__(self, T, K, H=32, A=32, mode='att', dropout=0.3, lr=1e-3,
                 seed=0, dtype=np.float32, posenc=False):
        self.posenc = posenc
        Din = 1 + (T if posenc else 0)
        assert mode in ('att', 'bi', 'uni')
        self.T, self.K, self.H, self.A, self.mode = T, K, H, A, mode
        self.dropout, self.lr, self.dt = dropout, lr, dtype
        rng = np.random.default_rng(seed)
        self.rng = rng
        def u(*shape, fan_in):
            lim = np.sqrt(6.0 / (fan_in + shape[-1]))
            return rng.uniform(-lim, lim, size=shape).astype(dtype)
        p = {}
        dirs = ['f'] if mode == 'uni' else ['f', 'b']
        self.dirs = dirs
        for d in dirs:
            p[f'Wx{d}'] = u(Din, 4 * H, fan_in=Din)
            # orthogonal-ish recurrent init
            q, _ = np.linalg.qr(rng.standard_normal((H, 4 * H)).T)
            p[f'Wh{d}'] = q.T.astype(dtype)[:H, :4 * H] if q.shape[1] >= H else u(H, 4 * H, fan_in=H)
            b = np.zeros(4 * H, dtype); b[H:2 * H] = 1.0  # forget-gate bias
            p[f'b{d}'] = b
        D = H * len(dirs)
        if mode == 'att':
            p['Wa'] = u(D, A, fan_in=D); p['ba'] = np.zeros(A, dtype)
            p['v'] = u(A, 1, fan_in=A)[:, 0]
        p['Wo'] = u(D, K, fan_in=D); p['bo'] = np.zeros(K, dtype)
        self.p = p
        self.m = {k: np.zeros_like(v) for k, v in p.items()}
        self.s = {k: np.zeros_like(v) for k, v in p.items()}
        self.t = 0

    # ---------- LSTM over one direction ----------
    def _lstm_fwd(self, X, d):
        p, H = self.p, self.H
        B, T = X.shape[:2]
        h = np.zeros((B, H), self.dt); c = np.zeros((B, H), self.dt)
        hs = np.empty((B, T, H), self.dt)
        cache = []
        order = range(T) if d == 'f' else range(T - 1, -1, -1)
        for t in order:
            x = X[:, t]
            z = x @ p[f'Wx{d}'] + h @ p[f'Wh{d}'] + p[f'b{d}']
            i = sigmoid(z[:, :H]); f = sigmoid(z[:, H:2 * H])
            o = sigmoid(z[:, 2 * H:3 * H]); g = np.tanh(z[:, 3 * H:])
            c_new = f * c + i * g
            tc = np.tanh(c_new)
            h_new = o * tc
            cache.append((t, x, h, c, i, f, o, g, tc))
            h, c = h_new, c_new
            hs[:, t] = h
        return hs, cache

    def _lstm_bwd(self, dhs, cache, d, grads):
        p, H = self.p, self.H
        B = dhs.shape[0]
        dh_next = np.zeros((B, H), self.dt); dc_next = np.zeros((B, H), self.dt)
        dWx = np.zeros_like(p[f'Wx{d}']); dWh = np.zeros_like(p[f'Wh{d}']); db = np.zeros_like(p[f'b{d}'])
        Wh_T = p[f'Wh{d}'].T
        for (t, x, h_prev, c_prev, i, f, o, g, tc) in reversed(cache):
            dh = dhs[:, t] + dh_next
            do = dh * tc
            dc = dc_next + dh * o * (1 - tc * tc)
            di = dc * g; dg = dc * i; df = dc * c_prev
            dc_next = dc * f
            dz = np.concatenate([di * i * (1 - i), df * f * (1 - f),
                                 do * o * (1 - o), dg * (1 - g * g)], axis=1)
            dWx += x.T @ dz; dWh += h_prev.T @ dz; db += dz.sum(0)
            dh_next = dz @ Wh_T
        grads[f'Wx{d}'] = dWx; grads[f'Wh{d}'] = dWh; grads[f'b{d}'] = db

    # ---------- full model ----------
    def forward(self, X, train=False):
        X = X.astype(self.dt, copy=False)[:, :, None]
        if self.posenc:
            E = np.broadcast_to(np.eye(self.T, dtype=self.dt), (X.shape[0], self.T, self.T))
            X = np.concatenate([X, E], axis=2)
        cache = {}
        outs = []
        for d in self.dirs:
            hs, c = self._lstm_fwd(X, d)
            cache[d] = c; outs.append(hs)
        Hs = np.concatenate(outs, axis=2) if len(outs) > 1 else outs[0]   # B,T,D
        cache['Hs'] = Hs
        p = self.p
        if self.mode == 'att':
            U = np.tanh(Hs @ p['Wa'] + p['ba'])                 # B,T,A
            e = U @ p['v']                                       # B,T
            e = e - e.max(1, keepdims=True)
            a = np.exp(e); a /= a.sum(1, keepdims=True)
            ctx = (a[:, :, None] * Hs).sum(1)                   # B,D
            cache.update(U=U, a=a)
        elif self.mode == 'bi':
            ctx = np.concatenate([Hs[:, -1, :self.H], Hs[:, 0, self.H:]], axis=1)
        else:
            ctx = Hs[:, -1]
        if train and self.dropout > 0:
            mask = (self.rng.random(ctx.shape) >= self.dropout).astype(self.dt) / (1 - self.dropout)
            ctx = ctx * mask; cache['mask'] = mask
        cache['ctx'] = ctx
        logits = ctx @ p['Wo'] + p['bo']
        self._cache = cache
        return logits

    def backward(self, dlogits):
        p, c, H = self.p, self._cache, self.H
        g = {}
        ctx, Hs = c['ctx'], c['Hs']
        g['Wo'] = ctx.T @ dlogits; g['bo'] = dlogits.sum(0)
        dctx = dlogits @ p['Wo'].T
        if 'mask' in c: dctx = dctx * c['mask']
        dHs = np.zeros_like(Hs)
        if self.mode == 'att':
            a, U = c['a'], c['U']
            dHs += a[:, :, None] * dctx[:, None, :]
            da = (Hs * dctx[:, None, :]).sum(2)                  # B,T
            de = a * (da - (a * da).sum(1, keepdims=True))
            g['v'] = np.einsum('bta,bt->a', U, de)
            dU = de[:, :, None] * p['v'][None, None, :]
            dpre = dU * (1 - U * U)
            g['Wa'] = np.einsum('btd,bta->da', Hs, dpre); g['ba'] = dpre.sum((0, 1))
            dHs += dpre @ p['Wa'].T
        elif self.mode == 'bi':
            dHs[:, -1, :H] += dctx[:, :H]; dHs[:, 0, H:] += dctx[:, H:]
        else:
            dHs[:, -1] += dctx
        for k, d in enumerate(self.dirs):
            self._lstm_bwd(dHs[:, :, k * H:(k + 1) * H], c[d], d, g)
        return g

    @staticmethod
    def loss_grad(logits, y, w):
        z = logits - logits.max(1, keepdims=True)
        P = np.exp(z); P /= P.sum(1, keepdims=True)
        B = len(y)
        sw = w[y]
        norm = sw.sum()
        loss = -(sw * np.log(P[np.arange(B), y] + 1e-12)).sum() / norm
        d = P.copy(); d[np.arange(B), y] -= 1
        d *= (sw / norm)[:, None]
        return loss, d.astype(logits.dtype)

    def adam(self, g, b1=0.9, b2=0.999, eps=1e-8, clip=5.0):
        tot = np.sqrt(sum(float((v * v).sum()) for v in g.values()))
        sc = min(1.0, clip / (tot + 1e-12))
        self.t += 1
        for k, v in g.items():
            v = v * sc
            self.m[k] = b1 * self.m[k] + (1 - b1) * v
            self.s[k] = b2 * self.s[k] + (1 - b2) * v * v
            mh = self.m[k] / (1 - b1 ** self.t); sh = self.s[k] / (1 - b2 ** self.t)
            self.p[k] -= (self.lr * mh / (np.sqrt(sh) + eps)).astype(self.dt)

    def predict_proba(self, X, bs=4096):
        out = []
        for i in range(0, len(X), bs):
            z = self.forward(X[i:i + bs])
            z = z - z.max(1, keepdims=True); P = np.exp(z); P /= P.sum(1, keepdims=True)
            out.append(P)
        return np.concatenate(out)

    def fit(self, X, y, Xv, yv, class_w, epochs=20, bs=256, patience=3, log=print, lr_decay=1.0):
        best, best_p, bad = np.inf, None, 0
        hist = []
        n = len(X)
        for ep in range(epochs):
            idx = self.rng.permutation(n); tl = 0
            for s in range(0, n, bs):
                b = idx[s:s + bs]
                logits = self.forward(X[b], train=True)
                l, dl = self.loss_grad(logits, y[b], class_w)
                self.adam(self.backward(dl)); tl += l * len(b)
            Pv = self.predict_proba(Xv)
            vl = -(class_w[yv] * np.log(Pv[np.arange(len(yv)), yv] + 1e-12)).sum() / class_w[yv].sum()
            hist.append((ep + 1, tl / n, float(vl)))
            log(f'epoch {ep+1} train_loss {tl/n:.5f} val_loss {vl:.5f}')
            if vl < best - 1e-5:
                best, bad = vl, 0
                best_p = {k: v.copy() for k, v in self.p.items()}
            else:
                bad += 1
                self.lr *= lr_decay
                if bad >= patience: break
        self.p = best_p
        return hist
