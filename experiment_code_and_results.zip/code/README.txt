Experiment code for "An Attention-Based BiLSTM Framework with Binary Grey Wolf Optimization for
DoS and DDoS Attack Detection in SDN". Requires Python 3, numpy, pandas, scikit-learn.
(Paths inside the scripts point to /home/claude/exp; edit them for your machine.)

1. python prep.py CICIDS2017-DOS__IB_.csv data.npz        # clean, dedupe, split 70/10/20, scale
2. python bgwo.py data.npz bgwo.json 1,2,3,4,5            # 5 BGWO runs; save best mask as selected.json
3. python classic.py results/classic_all.json             # KNN, RF, Linear SVM, MLP on 70 features
   python classic.py results/classic_sel.json sel         # same on selected features
4. python run_rnn.py <binary|multi> <att|bi|uni> <all|sel> <seed> out.json sqrt 3e-3 1 1 64
   (proposed = att sel, seeds 42 7 99; baselines uni/bi sel seed 42; ablation att all seed 42)
5. python aggregate.py                                    # -> final_results.json (all paper numbers)
rnn.py is a from-scratch NumPy LSTM/BiLSTM/attention-BiLSTM; gradients verified by finite differences.
